import java.util.Scanner;

class Program {
    public static void main(String[] args) {
        Bar bar = new Bar();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Name: ");
        while (scanner.hasNextLine()) {
            String name = scanner.nextLine();
            System.out.print("Order: ");
            String drink = scanner.nextLine();

            try {
                System.out.format("$%.02f\n", bar.getPrice(name, drink));
            } catch (DrinkNotFoundException e) {
                System.out.println(e.getMessage());
            }

            System.out.print("Name: ");
        }
    }
}