public interface IDiscountStrategy {
    double discount(double price);
}

class DefaultDiscountStrategy implements IDiscountStrategy {
    @Override
    public double discount(double price) {
        return price;
    }
}

class MemberDiscountStrategy implements IDiscountStrategy {
    @Override
    public double discount(double price) {
        return price * 0.9;
    }
}

class FamilyDiscountStrategy implements IDiscountStrategy {
    @Override
    public double discount(double price) {
        return price * 0.01;
    }
}