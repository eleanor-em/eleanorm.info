import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Bar {
    private final Map<String, Double> menu = new HashMap<>();
    private final List<String> memberNames = new ArrayList<>();
    private final List<String> familyNames = new ArrayList<>();

    public Bar() {
        menu.put("water", 0.00);
        menu.put("soft drink", 6.00);
        menu.put("ginger beer", 9.50);

        memberNames.add("alice");
        memberNames.add("bob");

        familyNames.add("shanika");
        familyNames.add("rohyl");
    }

    private IDiscountStrategy getStrategy(String name) {
        if (familyNames.contains(name.toLowerCase())) {
            return new FamilyDiscountStrategy();
        } else if (memberNames.contains(name.toLowerCase())) {
            return new MemberDiscountStrategy();
        } else {
            return new DefaultDiscountStrategy();
        }
    }

    public double getPrice(String customerName, String drink)
            throws DrinkNotFoundException {
        if (!menu.containsKey(drink)) {
            throw new DrinkNotFoundException(drink);
        }

        double price = menu.get(drink);
        return getStrategy(customerName).discount(price);
    }
}Q

class DrinkNotFoundException extends Exception {
    public DrinkNotFoundException(String drink) {q
        super("unknown drink: " + drink);
    }
}