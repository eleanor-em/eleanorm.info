public abstract class Shape {
    private final double centreX;
    private final double centreY;

    public Shape(double centreX, double centreY) {
        this.centreX = centreX;
        this.centreY = centreY;
    }

    public double getCentreX() { return centreX; }
    public double getCentreY() { return centreY; }

    public abstract double getArea();

    public String toString() {
        return String.format("Shape at (%.2f, %.2f)",
                centreX,
                centreY);
    }
}
