class Program {
    public static void main(String[] args) {
        Shape[] shapes = new Shape[] {
                new Circle(0, 0, 5),
                new Square(1, 1, 20),
                new Triangle(2, 2, 5, 20)
        };

        for (Shape shape : shapes) {
            System.out.println("area: " + shape.getArea());
            System.out.println("shape is "
                + (isShapeLarge(shape) ? "" : "not ")
                + "large");
        }
    }

    public static boolean isShapeLarge(Shape shape) {
        return shape.getArea() > 100;
    }
}
