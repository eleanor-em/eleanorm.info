public class Square extends Shape {
    private final double width;

    public Square(double centreX, double centreY, double width) {
        super(centreX, centreY);
        this.width = width;
    }

    @Override
    public double getArea() {
        return width * width;
    }

    @Override
    public String toString() {
        return String.format("Square at (%.2f, %.2f) of width %.2f",
                getCentreX(),
                getCentreY(),
                width);
    }
}
