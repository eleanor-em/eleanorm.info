public class Triangle extends Shape {
    private final double base;
    private final double height;

    public Triangle(double centreX, double centreY, double base, double height) {
        super(centreX, centreY);
        this.base = base;
        this.height = height;
    }

    @Override
    public double getArea() {
        return 0.5 * base * height;
    }
}
