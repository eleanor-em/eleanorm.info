public class Circle extends Shape {
    private final double radius;

    public Circle(double centreX, double centreY, double radius) {
        super(centreX, centreY);

        this.radius = radius;
    }

    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }
}
