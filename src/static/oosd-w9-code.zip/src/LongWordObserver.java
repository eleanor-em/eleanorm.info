/**
 * A concrete {@link Observer<String>} that watches for any long words
 * in the updates.
 */
public class LongWordObserver extends Observer<String> {
    /**
     * Respond to any long words.
     * @param data the subject data
     */
    @Override
    public void update(String data) {
        if (data.length() > 7) {
            System.out.println("Wow, " + data + " is a long word!");
        }
    }
}
