import java.util.ArrayList;
import java.util.List;

/**
 * A concrete {@link Subject<String>} that stores a list of words.
 */
public class WordStore extends Subject<String> {
    private final List<String> words = new ArrayList<>();

    /**
     * Count the number of words the store has seen.
     * @return the word count
     */
    public int wordCount() {
        return words.size();
    }

    /**
     * Update the word store with a new word.
     * @param data the word to store
     */
    @Override
    public void update(String data) {
        super.update(data);
        words.add(data);
    }
}
