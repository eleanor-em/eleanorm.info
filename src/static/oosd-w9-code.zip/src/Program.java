import java.util.Scanner;

/**
 * Runs the program, asking the user for some input and processing the
 * input word by word.
 */
public class Program {
    /**
     * The entry point of the program.
     * @param args command line arguments (not used)
     */
    public static void main(String[] args) {
        WordStore store = new WordStore();
        LongWordObserver obs = new LongWordObserver();
        store.register(obs);

        Scanner scanner = new Scanner(System.in);
        do {
            store.update(scanner.next());
        } while (scanner.hasNext());
        System.out.println(store.wordCount() + " words");
    }
}
