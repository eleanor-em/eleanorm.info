/**
 * An abstract base class for the Observer design pattern, where an
 * Observer watches a {@link Subject<T>} object for any changes.
 * @param <T> the type of data used in updates
 */
public abstract class Observer<T> {
    /**
     * Updates this observer with data received from the subject.
     * @param data the subject data
     */
    public abstract void update(T data);
}
