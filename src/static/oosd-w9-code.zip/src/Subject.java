import java.util.ArrayList;
import java.util.List;

/**
 * An abstract base class for the Observer design pattern, which is
 * watched by an {@link Observer<T>} object for any changes.
 * @param <T> the type of data used in updates
 */
public abstract class Subject<T> {
    private final List<Observer<T>> observers = new ArrayList<>();

    /**
     * Registers an observer for updates.
     * @param o the observer to register
     */
    public void register(Observer<T> o) {
        observers.add(o);
    }

    /**
     * Deregisters an observer so that it stops receiving updates.
     * @param o the observer to deregister
     */
    public void deregister(Observer<T> o) {
        observers.remove(o);
    }

    /**
     * Update the subject with a piece of data to be passed on to the
     * observers.
     * @param data the data to pass on
     */
    public void update(T data) {
        for (Observer<T> o : observers) {
            o.update(data);
        }
    }
}
